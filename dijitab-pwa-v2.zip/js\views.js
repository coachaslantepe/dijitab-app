window.Views = {
    dashboard: () => {
        const clients = store.get('clients');
        const properties = store.get('properties');

        return `
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 animate-fade-in">
                <!-- Stats Cards -->
                <div class="bg-white dark:bg-dark-surface p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border hover-card">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="text-sm text-gray-500 dark:text-gray-400 font-medium">Toplam Portföy</p>
                            <h3 class="text-3xl font-bold text-gray-900 dark:text-white mt-2">${properties.length}</h3>
                        </div>
                        <div class="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-xl text-blue-600 dark:text-blue-400">
                            <i class="fa-solid fa-building text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-4 flex items-center text-sm text-green-600 dark:text-green-400">
                        <i class="fa-solid fa-arrow-trend-up mr-1"></i>
                        <span>Bu ay +${properties.filter(p => new Date(p.id).getMonth() === new Date().getMonth()).length} yeni</span>
                    </div>
                </div>

                <div class="bg-white dark:bg-dark-surface p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border hover-card">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="text-sm text-gray-500 dark:text-gray-400 font-medium">Aktif Müşteriler</p>
                            <h3 class="text-3xl font-bold text-gray-900 dark:text-white mt-2">${clients.length}</h3>
                        </div>
                        <div class="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-xl text-purple-600 dark:text-purple-400">
                            <i class="fa-solid fa-users text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-4 flex items-center text-sm text-gray-500 dark:text-gray-400">
                        <span>Son görüşme: Bugün</span>
                    </div>
                </div>

                <div class="bg-white dark:bg-dark-surface p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border hover-card">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="text-sm text-gray-500 dark:text-gray-400 font-medium">Ciro Hedefi</p>
                            <h3 class="text-3xl font-bold text-gray-900 dark:text-white mt-2">%45</h3>
                        </div>
                        <div class="p-3 bg-green-50 dark:bg-green-900/20 rounded-xl text-green-600 dark:text-green-400">
                            <i class="fa-solid fa-bullseye text-xl"></i>
                        </div>
                    </div>
                    <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5 mt-4">
                        <div class="bg-green-500 h-1.5 rounded-full" style="width: 45%"></div>
                    </div>
                </div>
            </div>

            <!-- Market Ticker (Real Data) -->
            <div class="mt-8 bg-gradient-to-r from-gray-900 to-gray-800 rounded-2xl p-6 text-white shadow-lg animate-fade-in" style="animation-delay: 0.1s">
                <div class="flex flex-col md:flex-row justify-between items-center gap-4">
                    <div class="flex items-center gap-3">
                        <div class="p-2 bg-white/10 rounded-lg backdrop-blur-sm">
                            <i class="fa-solid fa-chart-line"></i>
                        </div>
                        <span class="font-medium">Canlı Piyasa</span>
                        <span class="text-xs text-gray-400 ml-2" id="last-update">Güncelleniyor...</span>
                    </div>
                    <div class="flex gap-6 text-sm" id="market-data">
                        <div class="flex items-center gap-2">
                            <span class="text-gray-400">USD</span>
                            <span class="font-bold text-white">...</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <span class="text-gray-400">EUR</span>
                            <span class="font-bold text-white">...</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <span class="text-gray-400">GBP</span>
                            <span class="font-bold text-white">...</span>
                        </div>
                         <div class="flex items-center gap-2">
                            <span class="text-gray-400">ALTIN</span>
                            <span class="font-bold text-white">...</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
                <!-- Recent Clients -->
                <div class="bg-white dark:bg-dark-surface rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border p-6 animate-fade-in" style="animation-delay: 0.2s">
                    <h3 class="text-lg font-bold mb-4">Son Müşteriler</h3>
                    <div class="space-y-4">
                        ${clients.slice(0, 3).map(client => `
                            <div class="flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-xl transition-colors cursor-pointer group">
                                <div class="flex items-center gap-3">
                                    <div class="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold">
                                        ${client.name.charAt(0)}
                                    </div>
                                    <div>
                                        <h4 class="font-medium group-hover:text-blue-600 transition-colors">${client.name}</h4>
                                        <p class="text-xs text-gray-500">${client.type}</p>
                                    </div>
                                </div>
                                <button class="text-gray-400 hover:text-blue-600"><i class="fa-solid fa-chevron-right"></i></button>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <!-- Quick Tasks -->
                <div class="bg-white dark:bg-dark-surface rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border p-6 animate-fade-in" style="animation-delay: 0.3s">
                    <h3 class="text-lg font-bold mb-4">Bugünün İşleri</h3>
                    <div class="space-y-3">
                        ${store.get('tasks').slice(0, 3).map(task => `
                            <div class="flex items-center gap-3 p-2">
                                <input type="checkbox" ${task.completed ? 'checked' : ''} class="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                                <span class="${task.completed ? 'line-through text-gray-400' : ''}">${task.text}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
    },

    turnover: () => {
        const transactions = store.get('transactions');
        const income = transactions.filter(t => t.type === 'income');
        const totalTurnover = income.reduce((sum, t) => sum + t.amount, 0);
        const targetTurnover = 5000000; // Example target: 5M TL
        const progress = Math.min((totalTurnover / targetTurnover) * 100, 100);
        const vatTotal = totalTurnover * 0.20;
        const netIncome = totalTurnover - vatTotal;

        return `
            <div class="space-y-6 animate-fade-in">
                <!-- Header -->
                <div class="bg-gradient-to-r from-blue-600 to-blue-800 rounded-2xl p-8 text-white shadow-lg">
                    <div class="flex justify-between items-start mb-6">
                        <div>
                            <p class="text-blue-100 font-medium mb-1">Yıllık Toplam Ciro</p>
                            <h2 class="text-4xl font-bold">${new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(totalTurnover)}</h2>
                        </div>
                        <div class="p-3 bg-white/10 rounded-xl backdrop-blur-sm">
                            <i class="fa-solid fa-trophy text-2xl text-yellow-300"></i>
                        </div>
                    </div>
                    
                    <div class="space-y-2">
                        <div class="flex justify-between text-sm text-blue-100">
                            <span>Yıllık Hedef: ${new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(targetTurnover)}</span>
                            <span>%${progress.toFixed(1)}</span>
                        </div>
                        <div class="w-full bg-black/20 rounded-full h-2">
                            <div class="bg-white h-2 rounded-full transition-all duration-1000" style="width: ${progress}%"></div>
                        </div>
                        <p class="text-xs text-blue-200 mt-2">Hedefe kalan: ${new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(targetTurnover - totalTurnover)}</p>
                    </div>
                </div>

                <!-- Detailed Stats -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div class="bg-white dark:bg-dark-surface p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border">
                        <div class="flex items-center gap-3 mb-2">
                            <div class="p-2 bg-green-50 dark:bg-green-900/20 rounded-lg text-green-600">
                                <i class="fa-solid fa-money-bill-wave"></i>
                            </div>
                            <h3 class="font-bold text-gray-900 dark:text-white">Net Gelir</h3>
                        </div>
                        <p class="text-2xl font-bold text-gray-900 dark:text-white">${new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(netIncome)}</p>
                        <p class="text-xs text-gray-500 mt-1">KDV düşülmüş tutar</p>
                    </div>

                    <div class="bg-white dark:bg-dark-surface p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border">
                        <div class="flex items-center gap-3 mb-2">
                            <div class="p-2 bg-orange-50 dark:bg-orange-900/20 rounded-lg text-orange-600">
                                <i class="fa-solid fa-file-invoice-dollar"></i>
                            </div>
                            <h3 class="font-bold text-gray-900 dark:text-white">Toplam KDV (%20)</h3>
                        </div>
                        <p class="text-2xl font-bold text-gray-900 dark:text-white">${new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(vatTotal)}</p>
                        <p class="text-xs text-gray-500 mt-1">Devlete ödenecek tahmini vergi</p>
                    </div>

                    <div class="bg-white dark:bg-dark-surface p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border">
                        <div class="flex items-center gap-3 mb-2">
                            <div class="p-2 bg-purple-50 dark:bg-purple-900/20 rounded-lg text-purple-600">
                                <i class="fa-solid fa-handshake"></i>
                            </div>
                            <h3 class="font-bold text-gray-900 dark:text-white">İşlem Adedi</h3>
                        </div>
                        <p class="text-2xl font-bold text-gray-900 dark:text-white">${income.length}</p>
                        <p class="text-xs text-gray-500 mt-1">Başarılı satış/kiralama</p>
                    </div>
                </div>

                <!-- Transaction Breakdown -->
                <div class="bg-white dark:bg-dark-surface rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border p-6">
                    <h3 class="font-bold text-lg text-gray-900 dark:text-white mb-4">Ciro Detayları</h3>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-sm">
                            <thead class="bg-gray-50 dark:bg-gray-800/50 text-gray-500 dark:text-gray-400">
                                <tr>
                                    <th class="px-6 py-4 font-medium">İşlem</th>
                                    <th class="px-6 py-4 font-medium">Tarih</th>
                                    <th class="px-6 py-4 font-medium">Kategori</th>
                                    <th class="px-6 py-4 font-medium text-right">Tutar</th>
                                    <th class="px-6 py-4 font-medium text-right">KDV</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100 dark:divide-dark-border">
                                ${income.map(t => `
                                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                                        <td class="px-6 py-4 font-medium text-gray-900 dark:text-white">${t.description}</td>
                                        <td class="px-6 py-4 text-gray-500">${t.date}</td>
                                        <td class="px-6 py-4">
                                            <span class="px-2 py-1 rounded-lg text-xs font-medium bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                                                ${t.category}
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 text-right font-bold text-gray-900 dark:text-white">
                                            ${new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(t.amount)}
                                        </td>
                                        <td class="px-6 py-4 text-right text-gray-500">
                                            ${new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(t.amount * 0.20)}
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    },
    portfolio: () => {
        const properties = store.get('properties');
        return `
            <div class="space-y-6 animate-fade-in">
                <!-- Toolbar -->
                <div class="flex justify-between items-center bg-white dark:bg-dark-surface p-4 rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border">
                    <div class="relative">
                        <i class="fa-solid fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                        <input type="text" placeholder="Portföyde ara..." class="pl-10 pr-4 py-2 bg-gray-50 dark:bg-gray-800 border-none rounded-xl text-sm focus:ring-2 focus:ring-blue-500 w-64">
                    </div>
                    <button onclick="App.openModal('Yeni İlan Ekle', Views.forms.addProperty())" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition-colors flex items-center gap-2">
                        <i class="fa-solid fa-plus"></i> İlan Ekle
                    </button>
                </div>

                <!-- Property Grid -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    ${properties.map(prop => `
                        <div class="bg-white dark:bg-dark-surface rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border overflow-hidden hover-card group">
                            <div class="h-48 bg-gray-200 dark:bg-gray-700 relative overflow-hidden">
                                <div class="absolute inset-0 flex items-center justify-center text-gray-400">
                                    <i class="fa-solid fa-image text-4xl"></i>
                                </div>
                                <div class="absolute top-3 right-3 bg-white/90 dark:bg-dark-surface/90 backdrop-blur-sm px-3 py-1 rounded-lg text-xs font-bold shadow-sm">
                                    ${prop.status}
                                </div>
                            </div>
                            <div class="p-5">
                                <div class="flex justify-between items-start mb-2">
                                    <h3 class="font-bold text-lg text-gray-900 dark:text-white line-clamp-1">${prop.title}</h3>
                                </div>
                                <p class="text-blue-600 dark:text-blue-400 font-bold text-xl mb-4">
                                    ${new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(prop.price)}
                                </p>
                                <div class="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400 mb-4">
                                    <div class="flex items-center gap-1">
                                        <i class="fa-solid fa-location-dot"></i>
                                        <span>${prop.location}</span>
                                    </div>
                                    <div class="flex items-center gap-1">
                                        <i class="fa-solid fa-tag"></i>
                                        <span>${prop.type}</span>
                                    </div>
                                </div>
                                <div class="pt-4 border-t border-gray-100 dark:border-dark-border flex justify-between items-center">
                                    <span class="text-xs text-gray-400">Eklenme: Bugün</span>
                                    <button class="text-blue-600 hover:text-blue-700 text-sm font-medium">Detaylar <i class="fa-solid fa-arrow-right ml-1"></i></button>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
                ${properties.length === 0 ? `
                    <div class="p-12 text-center text-gray-500 bg-white dark:bg-dark-surface rounded-2xl border border-dashed border-gray-300 dark:border-dark-border">
                        <i class="fa-solid fa-building-circle-xmark text-4xl mb-3 text-gray-300"></i>
                        <p>Henüz ilan eklenmemiş.</p>
                    </div>
                ` : ''}
            </div>
        `;
    },

    calendar: () => {
        const tasks = store.get('tasks');
        const today = new Date();
        const currentMonth = today.getMonth();
        const currentYear = today.getFullYear();
        const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
        const monthName = new Intl.DateTimeFormat('tr-TR', { month: 'long', year: 'numeric' }).format(today);

        return `
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
                <!-- Calendar View -->
                <div class="lg:col-span-2 bg-white dark:bg-dark-surface rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="font-bold text-lg text-gray-900 dark:text-white capitalize">${monthName}</h3>
                        <div class="flex gap-2">
                            <button class="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg"><i class="fa-solid fa-chevron-left"></i></button>
                            <button class="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg"><i class="fa-solid fa-chevron-right"></i></button>
                        </div>
                    </div>
                    <div class="grid grid-cols-7 gap-2 text-center mb-2 text-gray-400 text-sm font-medium">
                        <div>Pzt</div><div>Sal</div><div>Çar</div><div>Per</div><div>Cum</div><div>Cmt</div><div>Paz</div>
                    </div>
                    <div class="grid grid-cols-7 gap-2">
                        ${Array.from({ length: daysInMonth }, (_, i) => {
            const day = i + 1;
            const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const isToday = day === today.getDate();
            const hasTask = tasks.some(t => t.date === dateStr);

            return `
                                <div onclick="App.selectDate('${dateStr}')" class="aspect-square flex flex-col items-center justify-center rounded-xl text-sm cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors relative ${isToday ? 'bg-blue-600 text-white hover:bg-blue-700 font-bold shadow-lg shadow-blue-600/20' : 'text-gray-700 dark:text-gray-300'}">
                                    ${day}
                                    ${hasTask ? `<span class="w-1.5 h-1.5 rounded-full ${isToday ? 'bg-white' : 'bg-blue-500'} mt-1"></span>` : ''}
                                </div>
                            `;
        }).join('')}
                    </div>
                </div>

                <!-- Daily Tasks -->
                <div class="bg-white dark:bg-dark-surface rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border p-6 flex flex-col h-full">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="font-bold text-lg text-gray-900 dark:text-white">Bugünün İşleri</h3>
                        <button onclick="App.openModal('Yeni Görev Ekle', Views.forms.addTask())" class="text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 p-2 rounded-lg transition-colors">
                            <i class="fa-solid fa-plus"></i>
                        </button>
                    </div>
                    
                    <div class="space-y-3 flex-1 overflow-y-auto">
                        ${tasks.filter(t => t.date === today.toISOString().split('T')[0]).map(task => `
                            <div class="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800/50 rounded-xl group hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
                                <input type="checkbox" ${task.completed ? 'checked' : ''} onchange="App.toggleTask(${task.id})" class="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500 cursor-pointer">
                                <span class="flex-1 text-sm ${task.completed ? 'line-through text-gray-400' : 'text-gray-700 dark:text-gray-300'}">${task.text}</span>
                                <button onclick="App.deleteTask(${task.id})" class="text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </div>
                        `).join('')}
                        ${tasks.filter(t => t.date === today.toISOString().split('T')[0]).length === 0 ? '<p class="text-gray-400 text-center text-sm py-4">Bugün için görev yok.</p>' : ''}
                    </div>
                </div>
            </div>
        `;
    },

    finance: () => {
        const transactions = store.get('transactions');
        const income = transactions.filter(t => t.type === 'income');
        const expenses = transactions.filter(t => t.type === 'expense');

        // Calculate totals
        const totalIncome = income.reduce((sum, item) => sum + item.amount, 0);
        const totalExpense = expenses.reduce((sum, item) => sum + item.amount, 0);
        const netProfit = totalIncome - totalExpense;

        return `
    < div class="space-y-6 animate-fade-in" >
                < !--Summary Cards-- >
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div class="bg-white dark:bg-dark-surface p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border">
                        <p class="text-sm text-gray-500 dark:text-gray-400 font-medium">Toplam Gelir</p>
                        <h3 class="text-2xl font-bold text-green-600 dark:text-green-400 mt-2">
                            ${new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(totalIncome)}
                        </h3>
                    </div>
                    <div class="bg-white dark:bg-dark-surface p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border">
                        <p class="text-sm text-gray-500 dark:text-gray-400 font-medium">Toplam Gider</p>
                        <h3 class="text-2xl font-bold text-red-600 dark:text-red-400 mt-2">
                            ${new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(totalExpense)}
                        </h3>
                    </div>
                    <div class="bg-white dark:bg-dark-surface p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border">
                        <p class="text-sm text-gray-500 dark:text-gray-400 font-medium">Net Kar</p>
                        <h3 class="text-2xl font-bold ${netProfit >= 0 ? 'text-blue-600 dark:text-blue-400' : 'text-red-600'} mt-2">
                            ${new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(netProfit)}
                        </h3>
                    </div>
                </div>

                <!--Transactions -->
    <div class="bg-white dark:bg-dark-surface rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border p-6">
        <div class="flex justify-between items-center mb-6">
            <h3 class="font-bold text-lg text-gray-900 dark:text-white">Son İşlemler</h3>
            <button onclick="App.openModal('Yeni İşlem Ekle', Views.forms.addTransaction())" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition-colors flex items-center gap-2">
                <i class="fa-solid fa-plus"></i> İşlem Ekle
            </button>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
                <thead class="bg-gray-50 dark:bg-gray-800/50 text-gray-500 dark:text-gray-400">
                    <tr>
                        <th class="px-6 py-4 font-medium">Açıklama</th>
                        <th class="px-6 py-4 font-medium">Tarih</th>
                        <th class="px-6 py-4 font-medium">Kategori</th>
                        <th class="px-6 py-4 font-medium text-right">Tutar</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-dark-border">
                    ${transactions
                .sort((a, b) => new Date(b.date) - new Date(a.date))
                .map(item => `
                                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                                        <td class="px-6 py-4 font-medium text-gray-900 dark:text-white">${item.description}</td>
                                        <td class="px-6 py-4 text-gray-500">${item.date}</td>
                                        <td class="px-6 py-4">
                                            <span class="px-2 py-1 rounded-lg text-xs font-medium ${item.type === 'income' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'}">
                                                ${item.category}
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 text-right font-bold ${item.type === 'income' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}">
                                            ${item.type === 'income' ? '+' : '-'}${new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(item.amount)}
                                        </td>
                                    </tr>
                                `).join('')}
                </tbody>
            </table>
            ${transactions.length === 0 ? `
                            <div class="p-8 text-center text-gray-500">
                                <i class="fa-solid fa-receipt text-4xl mb-3 text-gray-300"></i>
                                <p>Henüz işlem kaydı yok.</p>
                            </div>
                        ` : ''}
        </div>
    </div>
            </div>
    `;
    },

    social: () => {
        const posts = store.get('socialPosts') || [];

        return `
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
                <!-- Calendar / Planner -->
                <div class="lg:col-span-2 bg-white dark:bg-dark-surface rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="font-bold text-lg text-gray-900 dark:text-white">İçerik Takvimi</h3>
                        <button onclick="App.openModal('Yeni İçerik Planla', Views.forms.addSocialPost())" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition-colors flex items-center gap-2">
                            <i class="fa-solid fa-plus"></i> Planla
                        </button>
                    </div>
                    
                    <div class="space-y-4">
                        ${posts.length > 0 ? posts.map(post => `
                            <div class="flex items-start gap-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-xl border border-gray-100 dark:border-dark-border">
                                <div class="w-12 h-12 rounded-xl bg-white dark:bg-gray-800 flex items-center justify-center text-2xl shadow-sm text-blue-600">
                                    <i class="fa-brands fa-${post.platform.toLowerCase()}"></i>
                                </div>
                                <div class="flex-1">
                                    <div class="flex justify-between items-start">
                                        <h4 class="font-bold text-gray-900 dark:text-white">${post.title}</h4>
                                        <span class="text-xs font-medium px-2 py-1 rounded-lg bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400">${post.date}</span>
                                    </div>
                                    <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">${post.content}</p>
                                    <div class="flex gap-2 mt-3">
                                        <span class="text-xs text-gray-500 bg-white dark:bg-gray-800 px-2 py-1 rounded border border-gray-200 dark:border-dark-border">#emlak</span>
                                        <span class="text-xs text-gray-500 bg-white dark:bg-gray-800 px-2 py-1 rounded border border-gray-200 dark:border-dark-border">#yatırım</span>
                                    </div>
                                </div>
                            </div>
                        `).join('') : `
                            <div class="text-center py-12 text-gray-500">
                                <i class="fa-solid fa-calendar-days text-4xl mb-3 text-gray-300"></i>
                                <p>Planlanmış içerik bulunmuyor.</p>
                            </div>
                        `}
                    </div>
                </div>

                <!--Ideas & Notes-- >
    <div class="bg-white dark:bg-dark-surface rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border p-6">
        <h3 class="font-bold text-lg text-gray-900 dark:text-white mb-4">Fikirler & Notlar</h3>
        <div class="space-y-3">
            <div class="p-3 bg-yellow-50 dark:bg-yellow-900/10 border border-yellow-100 dark:border-yellow-900/20 rounded-xl">
                <p class="text-sm text-yellow-800 dark:text-yellow-200">🏠 Haftanın portföyü videosu çekilecek.</p>
            </div>
            <div class="p-3 bg-blue-50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/20 rounded-xl">
                <p class="text-sm text-blue-800 dark:text-blue-200">📊 Piyasa analizi postu hazırlanacak.</p>
            </div>
            <textarea placeholder="Yeni bir fikir ekle..." class="w-full p-3 rounded-xl bg-gray-50 dark:bg-gray-800 border-none text-sm focus:ring-2 focus:ring-blue-500 resize-none" rows="3"></textarea>
        </div>
    </div>
            </div>
    `;
    },

    // Form Templates
    forms: {
        addClient: () => `
    < form onsubmit = "App.handleClientSubmit(event)" class="space-y-4" >
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Ad Soyad</label>
                    <input type="text" name="name" required class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Telefon</label>
                    <input type="tel" name="phone" required class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Müşteri Tipi</label>
                    <select name="type" class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                        <option value="Alıcı">Alıcı</option>
                        <option value="Satıcı">Satıcı</option>
                        <option value="Kiracı">Kiracı</option>
                        <option value="Yatırımcı">Yatırımcı</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Notlar</label>
                    <textarea name="notes" rows="3" class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all"></textarea>
                </div>
                <div class="pt-4 flex justify-end gap-3">
                    <button type="button" onclick="App.closeModal()" class="px-4 py-2 rounded-xl text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800 transition-colors">İptal</button>
                    <button type="submit" class="px-6 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium transition-colors shadow-lg shadow-blue-600/20">Kaydet</button>
                </div>
            </form >
    `,
        addProperty: () => `
    < form onsubmit = "App.handlePropertySubmit(event)" class="space-y-4" >
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">İlan Başlığı</label>
                    <input type="text" name="title" required class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Fiyat (TL)</label>
                        <input type="number" name="price" required class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Konum</label>
                        <input type="text" name="location" required class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Emlak Tipi</label>
                        <select name="type" class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                            <option value="Konut">Konut</option>
                            <option value="Ticari">Ticari</option>
                            <option value="Arsa">Arsa</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Durum</label>
                        <select name="status" class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                            <option value="Satılık">Satılık</option>
                            <option value="Kiralık">Kiralık</option>
                        </select>
                    </div>
                </div>
                <div class="pt-4 flex justify-end gap-3">
                        <label class="cursor-pointer">
                            <input type="radio" name="type" value="income" class="peer sr-only" checked>
                            <div class="p-3 text-center rounded-xl border border-gray-200 dark:border-dark-border peer-checked:bg-green-50 peer-checked:border-green-500 peer-checked:text-green-700 dark:peer-checked:bg-green-900/20 dark:peer-checked:text-green-400 transition-all">
                                <i class="fa-solid fa-arrow-up mb-1"></i><br>Gelir
                            </div>
                        </label>
                        <label class="cursor-pointer">
                            <input type="radio" name="type" value="expense" class="peer sr-only">
                            <div class="p-3 text-center rounded-xl border border-gray-200 dark:border-dark-border peer-checked:bg-red-50 peer-checked:border-red-500 peer-checked:text-red-700 dark:peer-checked:bg-red-900/20 dark:peer-checked:text-red-400 transition-all">
                                <i class="fa-solid fa-arrow-down mb-1"></i><br>Gider
                            </div>
                        </label>
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Fiş/Fatura Okut (OCR)</label>
                    <div class="flex gap-2">
                        <input type="file" id="receiptInput" accept="image/*" class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 dark:file:bg-blue-900/20 dark:file:text-blue-400 transition-all">
                        <button type="button" onclick="App.scanReceipt()" class="px-4 py-2 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 rounded-xl hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors">
                            <i class="fa-solid fa-camera"></i>
                        </button>
                    </div>
                    <p id="ocrStatus" class="text-xs text-blue-600 mt-1 hidden">Taranıyor...</p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Açıklama</label>
                    <input type="text" name="description" id="descInput" required class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Tutar (TL)</label>
                        <input type="number" name="amount" id="amountInput" required class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Kategori</label>
                        <select name="category" id="categoryInput" class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                            <option value="Komisyon">Komisyon</option>
                            <option value="Danışmanlık">Danışmanlık</option>
                            <option value="Kira">Kira</option>
                            <option value="Reklam">Reklam</option>
                            <option value="Ulaşım">Ulaşım</option>
                            <option value="Yemek">Yemek</option>
                            <option value="Market">Market</option>
                            <option value="Yakıt">Yakıt</option>
                            <option value="Diğer">Diğer</option>
                        </select>
                    </div>
                </div>
                <div class="pt-4 flex justify-end gap-3">
                    <button type="button" onclick="App.closeModal()" class="px-4 py-2 rounded-xl text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800 transition-colors">İptal</button>
                    <button type="submit" class="px-6 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium transition-colors shadow-lg shadow-blue-600/20">Kaydet</button>
                </div>
            </form >
    `,
        addSocialPost: () => `
    < form onsubmit = "App.handleSocialSubmit(event)" class="space-y-4" >
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Platform</label>
                    <select name="platform" class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                        <option value="Instagram">Instagram</option>
                        <option value="Facebook">Facebook</option>
                        <option value="Twitter">Twitter</option>
                        <option value="Linkedin">LinkedIn</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Başlık</label>
                    <input type="text" name="title" required class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">İçerik Detayı</label>
                    <textarea name="content" rows="4" class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all"></textarea>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Tarih</label>
                    <input type="date" name="date" required class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all" value="${new Date().toISOString().split('T')[0]}">
                </div>
                <div class="pt-4 flex justify-end gap-3">
                    <button type="button" onclick="App.closeModal()" class="px-4 py-2 rounded-xl text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800 transition-colors">İptal</button>
                    <button type="submit" class="px-6 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium transition-colors shadow-lg shadow-blue-600/20">Planla</button>
                </div>
            </form >
    `,
        addTask: (date = '') => `
            <form onsubmit="App.handleTaskSubmit(event)" class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Görev</label>
                    <input type="text" name="text" required class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all" placeholder="Örn: Tapu dairesine gidilecek">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Tarih</label>
                    <input type="date" name="date" required value="${date || new Date().toISOString().split('T')[0]}" class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                </div>
                <div class="pt-4 flex justify-end gap-3">
                    <button type="button" onclick="App.closeModal()" class="px-4 py-2 rounded-xl text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800 transition-colors">İptal</button>
                    <button type="submit" class="px-6 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium transition-colors shadow-lg shadow-blue-600/20">Ekle</button>
                </div>
            </form>
        `,
        addTransaction: () => `
            <form onsubmit="App.handleTransactionSubmit(event)" class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">İşlem Tipi</label>
                    <div class="grid grid-cols-2 gap-4">
                        <label class="cursor-pointer">
                            <input type="radio" name="type" value="income" class="peer sr-only" checked>
                            <div class="p-3 text-center rounded-xl border border-gray-200 dark:border-dark-border peer-checked:bg-green-50 peer-checked:border-green-500 peer-checked:text-green-700 dark:peer-checked:bg-green-900/20 dark:peer-checked:text-green-400 transition-all">
                                <i class="fa-solid fa-arrow-up mb-1"></i><br>Gelir
                            </div>
                        </label>
                        <label class="cursor-pointer">
                            <input type="radio" name="type" value="expense" class="peer sr-only">
                            <div class="p-3 text-center rounded-xl border border-gray-200 dark:border-dark-border peer-checked:bg-red-50 peer-checked:border-red-500 peer-checked:text-red-700 dark:peer-checked:bg-red-900/20 dark:peer-checked:text-red-400 transition-all">
                                <i class="fa-solid fa-arrow-down mb-1"></i><br>Gider
                            </div>
                        </label>
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Fiş/Fatura Okut (OCR)</label>
                    <div class="flex gap-2">
                        <input type="file" id="receiptInput" accept="image/*" class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 dark:file:bg-blue-900/20 dark:file:text-blue-400 transition-all">
                        <button type="button" onclick="App.scanReceipt()" class="px-4 py-2 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 rounded-xl hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors">
                            <i class="fa-solid fa-camera"></i>
                        </button>
                    </div>
                    <p id="ocrStatus" class="text-xs text-blue-600 mt-1 hidden">Taranıyor...</p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Açıklama</label>
                    <input type="text" name="description" id="descInput" required class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Tutar (TL)</label>
                        <input type="number" name="amount" id="amountInput" required class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Kategori</label>
                        <select name="category" id="categoryInput" class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                            <option value="Komisyon">Komisyon</option>
                            <option value="Danışmanlık">Danışmanlık</option>
                            <option value="Kira">Kira</option>
                            <option value="Reklam">Reklam</option>
                            <option value="Ulaşım">Ulaşım</option>
                            <option value="Yemek">Yemek</option>
                            <option value="Market">Market</option>
                            <option value="Yakıt">Yakıt</option>
                            <option value="Diğer">Diğer</option>
                        </select>
                    </div>
                </div>
                <div class="pt-4 flex justify-end gap-3">
                    <button type="button" onclick="App.closeModal()" class="px-4 py-2 rounded-xl text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800 transition-colors">İptal</button>
                    <button type="submit" class="px-6 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium transition-colors shadow-lg shadow-blue-600/20">Kaydet</button>
                </div>
            </form>
        `,
        editProfile: () => {
            const user = store.state.user;
            return `
    < form onsubmit = "App.handleProfileSubmit(event)" class="space-y-4" >
                <div class="flex justify-center mb-6">
                    <div class="relative">
                        <img src="${user.avatar}" class="w-24 h-24 rounded-full border-4 border-white dark:border-dark-surface shadow-lg">
                        <div class="absolute bottom-0 right-0 bg-blue-600 text-white p-2 rounded-full w-8 h-8 flex items-center justify-center cursor-pointer hover:bg-blue-700 transition-colors">
                            <i class="fa-solid fa-camera text-xs"></i>
                        </div>
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Ad Soyad</label>
                        <input type="text" name="name" value="${user.name}" required class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Unvan</label>
                        <input type="text" name="title" value="${user.title}" required class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">E-posta</label>
                        <input type="email" name="email" value="${user.email || ''}" class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Telefon</label>
                        <input type="tel" name="phone" value="${user.phone || ''}" class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Profil Fotoğrafı URL</label>
                    <input type="url" name="avatar" value="${user.avatar}" class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Biyografi</label>
                    <textarea name="bio" rows="3" class="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-dark-border focus:ring-2 focus:ring-blue-500 transition-all">${user.bio || ''}</textarea>
                </div>
                <div class="pt-4 flex justify-end gap-3">
                    <button type="button" onclick="App.closeModal()" class="px-4 py-2 rounded-xl text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800 transition-colors">İptal</button>
                    <button type="submit" class="px-6 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium transition-colors shadow-lg shadow-blue-600/20">Güncelle</button>
                </div>
            </form >
    `;
        }
    }
};

