class Store {
    constructor() {
        this.state = {
            clients: [],
            properties: [],
            tasks: [],
            transactions: [], // Fixed: Added transactions array
            socialPosts: [],
            user: {
                name: 'Ahmet Yılmaz',
                title: 'Kıdemli Emlak Danışmanı',
                email: 'ahmet@emlakpro.com',
                phone: '0532 123 45 67',
                bio: '10 yıllık tecrübe ile lüks konut uzmanı.',
                avatar: 'https://ui-avatars.com/api/?name=Ahmet+Yilmaz&background=0ea5e9&color=fff'
            }
        };

        this.load();
    }

    load() {
        const saved = localStorage.getItem('dijitab_v1'); // Renamed key
        if (saved) {
            this.state = JSON.parse(saved);
            // Migration for old data if needed, or just ensure transactions exists
            if (!this.state.transactions) this.state.transactions = [];
        } else {
            // Seed initial data if empty
            this.seed();
        }
    }

    save() {
        localStorage.setItem('dijitab_v1', JSON.stringify(this.state));
    }

    seed() {
        this.state.clients = [
            { id: 1, name: 'Mehmet Demir', phone: '0555 123 45 67', type: 'Alıcı', notes: '3+1 daire arıyor, bütçe 5M TL' },
            { id: 2, name: 'Ayşe Kaya', phone: '0532 987 65 43', type: 'Satıcı', notes: 'Bağdat caddesindeki dükkanını satmak istiyor' }
        ];
        this.state.properties = [
            { id: 1, title: 'Lüks Rezidans Dairesi', price: 7500000, location: 'Kadıköy', type: 'Konut', status: 'Satılık' },
            { id: 2, title: 'Merkezi Ofis Katı', price: 45000, location: 'Levent', type: 'Ticari', status: 'Kiralık' }
        ];
        this.state.tasks = [
            { id: 1, text: 'Mehmet bey ile görüşme', completed: false, date: new Date().toISOString().split('T')[0] },
            { id: 2, text: 'Portföy fotoğraflarını güncelle', completed: true, date: new Date().toISOString().split('T')[0] }
        ];
        this.save();
    }

    // Generic CRUD helpers
    add(collection, item) {
        if (!this.state[collection]) return;
        item.id = Date.now();
        this.state[collection].push(item);
        this.save();
        return item;
    }

    update(collection, id, updates) {
        if (!this.state[collection]) return;
        const index = this.state[collection].findIndex(i => i.id === id);
        if (index !== -1) {
            this.state[collection][index] = { ...this.state[collection][index], ...updates };
            this.save();
        }
    }

    delete(collection, id) {
        if (!this.state[collection]) return;
        this.state[collection] = this.state[collection].filter(i => i.id !== id);
        this.save();
    }

    get(collection) {
        return this.state[collection] || [];
    }

    // Specific method for user object since it's not an array
    setUser(userData) {
        this.state.user = { ...this.state.user, ...userData };
        this.save();
    }
}

window.store = new Store();
