window.App = {
    init() {
        this.renderSidebar();
        this.renderHeader();
        this.setupRouter();
        this.loadTheme();
    },

    loadTheme() {
        if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    },

    toggleTheme() {
        if (document.documentElement.classList.contains('dark')) {
            document.documentElement.classList.remove('dark');
            localStorage.theme = 'light';
        } else {
            document.documentElement.classList.add('dark');
            localStorage.theme = 'dark';
        }
    },

    renderSidebar() {
        const sidebar = document.getElementById('sidebar');
        const user = store.state.user;
        const menuItems = [
            { id: 'dashboard', icon: 'fa-house', label: 'Panel' },
            { id: 'crm', icon: 'fa-users', label: 'Müşteriler' },
            { id: 'portfolio', icon: 'fa-building', label: 'Portföy' },
            { id: 'turnover', icon: 'fa-chart-pie', label: 'Ciro & Hedef' }, // New Module
            { id: 'calendar', icon: 'fa-calendar', label: 'Takvim' },
            { id: 'finance', icon: 'fa-wallet', label: 'Finans' },
            { id: 'social', icon: 'fa-hashtag', label: 'Sosyal Medya' },
        ];

        sidebar.innerHTML = `
            <div class="p-6 flex items-center gap-3">
                <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white">
                    <i class="fa-solid fa-layer-group"></i>
                </div>
                <h1 class="text-xl font-bold tracking-tight">DİJİ<span class="text-blue-600">TAB</span></h1>
            </div>
            
            <nav class="flex-1 px-4 space-y-1 overflow-y-auto">
                ${menuItems.map(item => `
                    <a href="#${item.id}" class="nav-link flex items-center gap-3 px-4 py-3 rounded-xl text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-blue-600 dark:hover:text-blue-400 transition-all group" data-page="${item.id}">
                        <i class="fa-solid ${item.icon} w-5 text-center group-hover:scale-110 transition-transform"></i>
                        <span class="font-medium">${item.label}</span>
                    </a>
                `).join('')}
            </nav>

            <div class="p-4 border-t border-gray-200 dark:border-dark-border">
                <div onclick="App.openModal('Profil Düzenle', Views.forms.editProfile())" class="flex items-center gap-3 px-4 py-2 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 rounded-xl transition-colors group">
                    <img src="${user.avatar}" class="w-10 h-10 rounded-full object-cover border-2 border-transparent group-hover:border-blue-600 transition-all">
                    <div class="flex-1 min-w-0">
                        <p class="text-sm font-bold text-gray-900 dark:text-white truncate">${user.name}</p>
                        <p class="text-xs text-gray-500 truncate">${user.title}</p>
                    </div>
                    <i class="fa-solid fa-gear text-gray-400 group-hover:text-blue-600 transition-colors"></i>
                </div>
            </div>
        `;
    },

    renderHeader() {
        const header = document.getElementById('header');
        header.innerHTML = `
            <div class="flex items-center gap-4">
                <button class="md:hidden text-gray-500 hover:text-gray-700">
                    <i class="fa-solid fa-bars text-xl"></i>
                </button>
                <h2 id="page-title" class="text-xl font-semibold text-gray-800 dark:text-white">Panel</h2>
            </div>

            <div class="flex items-center gap-4">
                <div class="relative hidden md:block">
                    <i class="fa-solid fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                    <input type="text" placeholder="Ara..." class="pl-10 pr-4 py-2 bg-gray-100 dark:bg-gray-800 border-none rounded-xl text-sm focus:ring-2 focus:ring-blue-500 w-64 transition-all">
                </div>
                
                <button onclick="App.toggleTheme()" class="w-10 h-10 rounded-xl flex items-center justify-center text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
                    <i class="fa-solid fa-moon dark:hidden"></i>
                    <i class="fa-solid fa-sun hidden dark:block text-yellow-500"></i>
                </button>
                
                <button class="w-10 h-10 rounded-xl flex items-center justify-center text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors relative">
                    <i class="fa-regular fa-bell"></i>
                    <span class="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white dark:border-dark-surface"></span>
                </button>
            </div>
        `;
    },

    setupRouter() {
        const handleRoute = () => {
            const hash = window.location.hash.slice(1) || 'dashboard';
            const view = Views[hash] || Views.dashboard;

            // Update active state in sidebar
            document.querySelectorAll('.nav-link').forEach(link => {
                if (link.dataset.page === hash) {
                    link.classList.add('bg-blue-50', 'dark:bg-blue-900/20', 'text-blue-600', 'dark:text-blue-400');
                    link.classList.remove('text-gray-600', 'dark:text-gray-400');
                } else {
                    link.classList.remove('bg-blue-50', 'dark:bg-blue-900/20', 'text-blue-600', 'dark:text-blue-400');
                    link.classList.add('text-gray-600', 'dark:text-gray-400');
                }
            });

            // Update Page Title
            const titles = {
                dashboard: 'Genel Bakış',
                crm: 'Müşteri Yönetimi',
                portfolio: 'Portföy',
                turnover: 'Ciro & Hedefler',
                calendar: 'Takvim & Planlama',
                finance: 'Finansal Durum',
                social: 'Sosyal Medya Planlayıcı'
            };
            const pageTitle = document.getElementById('page-title');
            if (pageTitle) pageTitle.innerText = titles[hash] || 'Panel';

            // Render View
            const container = document.getElementById('view-container');
            if (container) {
                container.innerHTML = view();
                // Re-initialize any view-specific logic if needed
                if (hash === 'turnover') this.fetchMarketData();
            }
        };

        window.addEventListener('hashchange', handleRoute);
        handleRoute(); // Initial load
    },

    openModal(title, content) {
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in';
        modal.id = 'active-modal';
        modal.innerHTML = `
            <div class="bg-white dark:bg-dark-surface rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden transform scale-95 opacity-0 transition-all duration-300" id="modal-content">
                <div class="p-6 border-b border-gray-100 dark:border-dark-border flex justify-between items-center">
                    <h3 class="text-lg font-bold text-gray-900 dark:text-white">${title}</h3>
                    <button onclick="App.closeModal()" class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition-colors">
                        <i class="fa-solid fa-xmark text-xl"></i>
                    </button>
                </div>
                <div class="p-6 max-h-[80vh] overflow-y-auto">
                    ${content}
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        // Animation
        requestAnimationFrame(() => {
            const content = modal.querySelector('#modal-content');
            content.classList.remove('scale-95', 'opacity-0');
            content.classList.add('scale-100', 'opacity-100');
        });
    },

    closeModal() {
        const modal = document.getElementById('active-modal');
        if (modal) {
            const content = modal.querySelector('#modal-content');
            content.classList.remove('scale-100', 'opacity-100');
            content.classList.add('scale-95', 'opacity-0');
            setTimeout(() => modal.remove(), 200);
        }
    },

    handleClientSubmit(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const client = {
            id: Date.now(),
            name: formData.get('name'),
            phone: formData.get('phone'),
            type: formData.get('type'),
            notes: formData.get('notes'),
            date: new Date().toISOString().split('T')[0]
        };
        store.add('clients', client);
        this.closeModal();
        window.dispatchEvent(new Event('hashchange'));
    },

    handlePropertySubmit(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const property = {
            id: Date.now(),
            title: formData.get('title'),
            price: Number(formData.get('price')),
            location: formData.get('location'),
            type: formData.get('type'),
            status: formData.get('status'),
            date: new Date().toISOString().split('T')[0]
        };
        store.add('properties', property);
        this.closeModal();
        window.dispatchEvent(new Event('hashchange'));
    },

    handleTaskSubmit(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const task = {
            id: Date.now(),
            text: formData.get('text'),
            date: formData.get('date'),
            completed: false
        };
        store.add('tasks', task);
        this.closeModal();
        window.dispatchEvent(new Event('hashchange'));
    },

    handleTransactionSubmit(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const transaction = {
            id: Date.now(),
            type: formData.get('type'),
            description: formData.get('description'),
            amount: Number(formData.get('amount')),
            category: formData.get('category'),
            date: new Date().toISOString().split('T')[0]
        };
        store.add('transactions', transaction);
        this.closeModal();
        window.dispatchEvent(new Event('hashchange'));
    },

    handleSocialSubmit(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const post = {
            id: Date.now(),
            platform: formData.get('platform'),
            title: formData.get('title'),
            content: formData.get('content'),
            date: formData.get('date')
        };
        store.add('socialPosts', post);
        this.closeModal();
        window.dispatchEvent(new Event('hashchange'));
    },

    handleProfileSubmit(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const user = {
            name: formData.get('name'),
            title: formData.get('title'),
            email: formData.get('email'),
            phone: formData.get('phone'),
            avatar: formData.get('avatar'),
            bio: formData.get('bio')
        };
        store.state.user = user;
        store.save();
        this.renderSidebar();
        this.closeModal();
    },

    async scanReceipt() {
        const input = document.getElementById('receiptInput');
        const status = document.getElementById('ocrStatus');

        if (input.files && input.files[0]) {
            status.classList.remove('hidden');
            status.innerText = 'Taranıyor...';

            try {
                const result = await Tesseract.recognize(input.files[0], 'tur', {
                    logger: m => status.innerText = `Taranıyor... %${Math.round(m.progress * 100)}`
                });

                const text = result.data.text;
                console.log('OCR Result:', text);

                // Simple regex to find amount (looks for numbers with comma or dot)
                const amountMatch = text.match(/(\d+[.,]\d{2})/);
                if (amountMatch) {
                    const amount = parseFloat(amountMatch[0].replace(',', '.'));
                    document.getElementById('amountInput').value = amount;
                    document.getElementById('descInput').value = 'Fiş Okuma: ' + text.substring(0, 20) + '...';
                    status.innerText = 'Tutar bulundu!';
                    status.className = 'text-xs text-green-600 mt-1';

                    // Auto-save logic
                    const transaction = {
                        id: Date.now(),
                        type: 'expense',
                        description: 'Fiş Okuma: ' + text.substring(0, 20) + '...',
                        amount: amount,
                        category: 'Diğer', // Default category
                        date: new Date().toISOString().split('T')[0]
                    };
                    store.add('transactions', transaction);
                    // Don't close modal, let user verify/edit
                } else {
                    status.innerText = 'Tutar bulunamadı.';
                    status.className = 'text-xs text-red-600 mt-1';
                }
            } catch (error) {
                console.error(error);
                status.innerText = 'Hata oluştu.';
                status.className = 'text-xs text-red-600 mt-1';
            }
        }
    },

    async fetchMarketData() {
        const marketEl = document.getElementById('market-data');
        const updateEl = document.getElementById('last-update');
        if (!marketEl) return;

        // Simulated API call
        const getData = () => {
            const randomChange = (base) => (base + (Math.random() - 0.5) * base * 0.02).toFixed(2);
            return {
                USD: randomChange(34.50),
                EUR: randomChange(37.20),
                GBP: randomChange(43.80),
                GOLD: randomChange(2450)
            };
        };

        const update = () => {
            const data = getData();
            marketEl.innerHTML = `
                <div class="flex items-center gap-2">
                    <span class="text-gray-400">USD</span>
                    <span class="font-bold text-white">${data.USD} <span class="text-xs text-green-400">▲</span></span>
                </div>
                <div class="flex items-center gap-2">
                    <span class="text-gray-400">EUR</span>
                    <span class="font-bold text-white">${data.EUR} <span class="text-xs text-red-400">▼</span></span>
                </div>
                <div class="flex items-center gap-2">
                    <span class="text-gray-400">GBP</span>
                    <span class="font-bold text-white">${data.GBP} <span class="text-xs text-green-400">▲</span></span>
                </div>
                 <div class="flex items-center gap-2">
                    <span class="text-gray-400">ALTIN</span>
                    <span class="font-bold text-white">${data.GOLD} <span class="text-xs text-green-400">▲</span></span>
                </div>
            `;
            updateEl.innerText = new Date().toLocaleTimeString();
        };

        update();
        setInterval(update, 30000); // Update every 30 seconds
    },

    toggleTask(id) {
        const tasks = store.get('tasks');
        const task = tasks.find(t => t.id === id);
        if (task) {
            store.update('tasks', id, { completed: !task.completed });
            window.dispatchEvent(new Event('hashchange'));
        }
    },

    deleteTask(id) {
        if (confirm('Bu görevi silmek istediğinize emin misiniz?')) {
            store.delete('tasks', id);
            window.dispatchEvent(new Event('hashchange'));
        }
    },

    selectDate(date) {
        // For now, just open the add task modal with the selected date pre-filled
        // In a real app, this could filter the task list or show a daily view
        this.openModal('Yeni Görev Ekle', Views.forms.addTask(date));
    }
};

document.addEventListener('DOMContentLoaded', () => App.init());
